# Keep OkHttp3 & Networking classes
-dontwarn okhttp3.**
-dontwarn okio.**
-keepnames class okhttp3.internal.publicsuffix.PublicSuffixDatabase

# Keep AndroidX Security Crypto
-keep class com.google.crypto.tink.** { *; }
-dontwarn com.google.crypto.tink.**

# Keep Domain Models for JSON parsing
-keep class vn.quan.trolyquan.domain.model.** { *; }
