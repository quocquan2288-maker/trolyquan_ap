package vn.quan.trolyquan.data.system

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import vn.quan.trolyquan.data.ai.LocalCommandFallbackParser
import vn.quan.trolyquan.domain.model.InstalledAppInfo

/**
 * Quét danh sách ứng dụng thực tế đã cài trên điện thoại qua Android PackageManager
 * và hỗ trợ tìm kiếm thông minh (fuzzy + alias tiếng Việt) để mở đúng ứng dụng.
 */
class InstalledAppsScanner(private val context: Context) {

    // Bảng ánh xạ các tên gọi phổ biến tại Việt Nam sang danh sách packageName chính thức
    private val knownAppAliases: Map<String, List<String>> = mapOf(
        "tiktok" to listOf("com.ss.android.ugc.trill", "com.zhiliaoapp.musically", "com.ss.android.ugc.aweme"),
        "tik tok" to listOf("com.ss.android.ugc.trill", "com.zhiliaoapp.musically"),
        "youtube" to listOf("com.google.android.youtube", "com.google.android.apps.youtube.music"),
        "ytb" to listOf("com.google.android.youtube"),
        "chrome" to listOf("com.android.chrome", "com.chrome.beta", "com.sec.android.app.sbrowser"),
        "trinh duyet" to listOf("com.android.chrome", "com.sec.android.app.sbrowser", "org.mozilla.firefox"),
        "zalo" to listOf("com.zing.zalo"),
        "facebook" to listOf("com.facebook.katana", "com.facebook.lite"),
        "fb" to listOf("com.facebook.katana", "com.facebook.lite"),
        "messenger" to listOf("com.facebook.orca", "com.facebook.mlite"),
        "maps" to listOf("com.google.android.apps.maps"),
        "ban do" to listOf("com.google.android.apps.maps"),
        "google maps" to listOf("com.google.android.apps.maps"),
        "gmail" to listOf("com.google.android.gm"),
        "spotify" to listOf("com.spotify.music"),
        "capcut" to listOf("com.lemon.lvoverseas"),
        "shopee" to listOf("com.shopee.vn"),
        "lazada" to listOf("com.lazada.android"),
        "grab" to listOf("com.grabtaxi.passenger"),
        "be" to listOf("xyz.be.customer"),
        "vneid" to listOf("com.vnid"),
        "telegram" to listOf("org.telegram.messenger", "org.thunderdog.challegram"),
        "instagram" to listOf("com.instagram.android"),
        "threads" to listOf("com.instagram.barcelona"),
        "may anh" to listOf("com.android.camera", "com.android.camera2", "com.sec.android.app.camera"),
        "camera" to listOf("com.android.camera", "com.android.camera2", "com.sec.android.app.camera"),
        " thu vien" to listOf("com.google.android.apps.photos", "com.sec.android.gallery3d"),
        "google photos" to listOf("com.google.android.apps.photos"),
        "ch play" to listOf("com.android.vending"),
        "play store" to listOf("com.android.vending"),
        "cua hang play" to listOf("com.android.vending"),
        "may tinh" to listOf("com.google.android.calculator", "com.sec.android.app.popupcalculator", "com.android.calculator2"),
        "dong ho" to listOf("com.google.android.deskclock", "com.sec.android.app.clockpackage", "com.android.deskclock"),
        "lich" to listOf("com.google.android.calendar", "com.samsung.android.calendar", "com.android.calendar")
    )

    suspend fun scanInstalledLaunchableApps(): List<InstalledAppInfo> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolveInfos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(
                mainIntent,
                PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_ALL.toLong())
            )
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(mainIntent, PackageManager.MATCH_ALL)
        }

        val uniquePackages = LinkedHashMap<String, InstalledAppInfo>()
        for (resolveInfo in resolveInfos) {
            val activityInfo = resolveInfo.activityInfo ?: continue
            val pkgName = activityInfo.packageName ?: continue
            if (pkgName == context.packageName) continue

            val label = try {
                resolveInfo.loadLabel(pm).toString().trim()
            } catch (_: Exception) {
                pkgName
            }
            if (label.isBlank()) continue

            val appFlags = activityInfo.applicationInfo?.flags ?: 0
            val isSystem = (appFlags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                (appFlags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0

            val normalized = LocalCommandFallbackParser.normalizeVietnamese("$label $pkgName")
            uniquePackages[pkgName] = InstalledAppInfo(
                appName = label,
                packageName = pkgName,
                normalizedSearchName = normalized,
                isSystemApp = isSystem
            )
        }

        uniquePackages.values.sortedWith(
            compareBy<InstalledAppInfo> { it.isSystemApp }.thenBy { it.appName.lowercase() }
        )
    }

    /**
     * Tìm kiếm ứng dụng phù hợp nhất từ câu lệnh của người dùng hoặc từ packageName do AI chỉ định.
     */
    fun findBestMatchingApp(
        targetQuery: String,
        installedApps: List<InstalledAppInfo>
    ): InstalledAppInfo? {
        val trimmed = targetQuery.trim()
        if (trimmed.isBlank()) return null

        // 1. Khớp chính xác theo packageName
        installedApps.firstOrNull { it.packageName.equals(trimmed, ignoreCase = true) }?.let {
            return it
        }

        val normQuery = LocalCommandFallbackParser.normalizeVietnamese(trimmed)

        // 2. Kiểm tra trong bảng alias phổ biến (TikTok, YouTube, Chrome, Zalo, FB...)
        for ((aliasKey, candidatePackages) in knownAppAliases) {
            if (normQuery == aliasKey || normQuery.contains(aliasKey)) {
                for (candidatePkg in candidatePackages) {
                    installedApps.firstOrNull {
                        it.packageName.equals(candidatePkg, ignoreCase = true)
                    }?.let { return it }
                }
            }
        }

        // 3. Khớp chính xác tên ứng dụng (không dấu)
        installedApps.firstOrNull {
            LocalCommandFallbackParser.normalizeVietnamese(it.appName) == normQuery
        }?.let { return it }

        // 4. Khớp tên ứng dụng bắt đầu bằng từ khóa hoặc chứa từ khóa
        installedApps.firstOrNull {
            val appNorm = LocalCommandFallbackParser.normalizeVietnamese(it.appName)
            appNorm.startsWith(normQuery) || normQuery.startsWith(appNorm)
        }?.let { return it }

        installedApps.firstOrNull {
            it.normalizedSearchName.contains(normQuery)
        }?.let { return it }

        return null
    }
}
