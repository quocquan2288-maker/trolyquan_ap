package vn.quan.trolyquan.domain.model

/**
 * Các loại lệnh điều khiển Android thực tế mà Trợ Lý Quân hỗ trợ.
 * Tuyệt đối không chứa lệnh giả lập hay vượt quá giới hạn bảo mật của Android.
 */
enum class CommandType(val displayTitle: String) {
    NONE("Trò chuyện"),
    OPEN_APP("Mở ứng dụng"),
    OPEN_SETTINGS("Mở cài đặt hệ thống"),
    TORCH_CONTROL("Điều khiển đèn pin"),
    VOLUME_CONTROL("Điều chỉnh âm lượng"),
    WIFI_PANEL("Bảng điều khiển Wi-Fi"),
    DIAL_NUMBER("Mở trình quay số"),
    CALL_NUMBER("Gọi điện thoại trực tiếp"),
    SET_ALARM("Đặt báo thức"),
    SET_TIMER("Đặt hẹn giờ"),
    WEB_SEARCH("Tìm kiếm Google"),
    YOUTUBE_SEARCH("Tìm kiếm trên YouTube"),
    OPEN_URL("Mở trang web")
}

/**
 * Cấu trúc lệnh hệ thống được trích xuất từ AI hoặc bộ phân tích nội bộ.
 */
data class SystemCommand(
    val type: CommandType = CommandType.NONE,
    val target: String = "",
    val stringValue: String = "",
    val booleanValue: Boolean? = null,
    val intValue: Int? = null,
    val hour: Int? = null,
    val minute: Int? = null,
    val requiresConfirmation: Boolean = false
)

/**
 * Kết quả thực thi thực tế từ tầng Android Native trả về cho UI và Lịch sử chat.
 */
data class ActionExecutionResult(
    val success: Boolean,
    val commandType: CommandType,
    val summaryTitle: String,
    val detailMessage: String,
    val requiresUserConfirmation: Boolean = false,
    val pendingCommand: SystemCommand? = null
)
